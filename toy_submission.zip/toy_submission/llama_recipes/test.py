from dataset.custom_dataset import TsotsaDataset
from random import randrange
# download_file(path)

tsotsa = TsotsaDataset('train')
# tsotsa._load_lima()
# print(tsotsa.dataset)

# bbq_dataset = tsotsa._load_bbq()
# tsotsa.prepare_bbq_scenario(bbq_dataset[randrange(len(bbq_dataset))])

# print(tsotsa._load_lima())

# BB dataset
# dataset_lima = tsotsa._load_lima()
# dataset_dolly = tsotsa._load_dolly()
# tsotsa.prepare_bb_scenario(dataset_lima[randrange(len(dataset_lima))])
# tsotsa.prepare_bb_scenario(dataset_dolly[randrange(len(dataset_dolly))])
# oasst1_dataset = tsotsa._load_oasst1()
# tsotsa.prepare_bb_scenario(oasst1_dataset[randrange(len(oasst1_dataset))])
# print(oasst1_dataset)
# Summarization
# xum_dataset = tsotsa._load_xsum()
# print(xum_dataset)
# cnn_dailymail_dataset = tsotsa._load_cnn_dailymail()
# print(cnn_dailymail_dataset)

# TruthfulQA dataset
ai2_arc_dataset = tsotsa._load_ai2_arc()
print(len(ai2_arc_dataset))
# thruthfulqa = tsotsa.truthfulqa()
# print(thruthfulqa)
# thruthfulqa1 = tsotsa.truthfulqa1()
# print(thruthfulqa1)
# tsotsa.prepare_truthfulqa_scenario(
# thruthfulqa1[randrange(len(thruthfulqa1))])
# com_qa_dataset = tsotsa._load_commonsense_qa()
# tsotsa.prepare_truthfulqa_scenario(
#     ai2_arc_dataset[randrange(len(ai2_arc_dataset))])

# print(ai2_arc_dataset.__len__())


# print(tsotsa._load_databricks())
# print(tsotsa._load_oasst1())
# print(tsotsa._load_redpajama())
